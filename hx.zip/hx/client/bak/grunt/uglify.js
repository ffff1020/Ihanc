module.exports = {
  dist:{
    src:[
      'dist/js/dist.js'
    ],
    dest:'dist/js/app.min.js'
  }
}