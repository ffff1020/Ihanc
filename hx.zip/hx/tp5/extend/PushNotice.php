<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/26 0026
 * Time: 下午 5:03
 */
include_once 'aliyun-php-sdk-core/Config.php';
include 'aliyun-php-sdk-push/Push/Request/V20160801/PushRequest.php';
use \Push\Request\V20160801 as Push;

class PushNotice
{
    public static function Push($title,$body,$alisa){
        // 设置你的AccessKeyId/AccessSecret/AppKey
        $accessKeyId = "LTAIxIOsy9LpzWGT";
        $accessKeySecret = "p6jPMZ23bLHPkLCGxSqLKZrz8sMvO6";
        $appKey = "25713205";
        $iClientProfile = DefaultProfile::getProfile("cn-hangzhou", $accessKeyId, $accessKeySecret);
        $client = new DefaultAcsClient($iClientProfile);
        $request = new Push\PushNoticeToAndroidRequest();
        $request->setAppKey($appKey);
        $request->setTarget("ALIAS"); //推送目标: DEVICE:按设备推送 ALIAS : 按别名推送 ACCOUNT:按帐号推送  TAG:按标签推送; ALL: 广播推送
        $request->setTargetValue($alisa); //根据Target来设定，如Target=DEVICE, 则对应的值为 设备id1,设备id2. 多个值使用逗号分隔.(帐号与设备有一次最多100个的限制)
        $request->setTitle($title);
        $request->setBody($body);
        $response = $client->getAcsResponse($request);
        return $response;
    }
}